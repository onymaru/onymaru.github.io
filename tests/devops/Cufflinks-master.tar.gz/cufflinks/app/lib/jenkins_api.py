import typing

import requests
from app import definitions
from app.lib import exceptions
from app.lib.keyring import Keyring
from app.lib.logger import asserted


BALL_COLOR = {
    'blue': 'success',
    'red': 'failure',
    'yellow': 'unstable',
    'grey': 'disabled',
    'disabled': 'disabled',
    'aborted': 'aborted',
    'notbuilt': 'not built'
}


class Build:
    def __init__(self, **kwargs):
        self._data = kwargs

    @property
    def display_name(self) -> str:
        return self._data['displayName']

    @property
    def url(self) -> str:
        return self._data['url']

    @property
    def result(self) -> str:
        return self._data['result']

    @property
    def building(self) -> bool:
        return self._data['building']


class Job:
    def __init__(self, **kwargs):
        self.name = kwargs.get('name')
        self.color = kwargs.get('color')
        self.url = kwargs.get('url')

    @property
    def status(self) -> str:
        if self.color and 'anime' in self.color:
            return 'active'
        else:
            return BALL_COLOR.get(self.color)

    @property
    def is_active(self) -> bool:
        return self.status == 'active'

    @property
    def last_build(self) -> Build:
        return get_last_build(self)


@asserted
def get_auth():
    return Keyring().jenkins


@asserted
def jenkins_get(url):
    auth = get_auth()
    url = f'{definitions.JENKINS_URL}/{url}'
    try:
        response = requests.get(url, auth=(auth.username, auth.password))
    except requests.exceptions.ConnectionError as exc:
        raise exceptions.JenkinsResponseError(f'Connection timeout: {exc}')
    if response.status_code == 401:
        raise exceptions.JenkinsResponseError(f'Failed to auth, check your credentials at {definitions.AUTH_FILE_PATH}')
    elif response.status_code != 200:
        raise exceptions.JenkinsResponseError(
            f'Incorrect response from server: CODE {response.status_code}, {response.text}')
    return response


@asserted
def get_jobs() -> typing.List[Job]:
    response = jenkins_get('/api/json?tree=jobs[name,url,color]&pretty=true')
    job_list = response.json().get('jobs')
    return [Job(**x) for x in job_list]


@asserted
def get_servers() -> typing.List[Job]:
    return [x for x in get_jobs() if x.name and x.name.startswith('server')]


@asserted
def get_active_jobs() -> typing.List[Job]:
    return [x for x in get_jobs() if x.is_active]


@asserted
def get_last_build(job: Job) -> Build:
    last_build_number = jenkins_get(f'/job/{job.name}/api/json?tree=lastBuild[number]&pretty=true').json()['lastBuild'][
        'number']
    last_build = jenkins_get(f'/job/{job.name}/{last_build_number}/api/json?pretty=true').json()
    return Build(**last_build)
