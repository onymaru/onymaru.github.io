import os
import logging
import sys
from logging import handlers, Formatter
from app.lib import exceptions
from app import definitions

logging_levels = {
    'critical': logging.CRITICAL,
    'error': logging.ERROR,
    'warning': logging.WARNING,
    'info': logging.INFO,
    'debug': logging.DEBUG
}

LOG_FORMAT = '[%(asctime)-s] - %(filename)-30s %(levelname)-8s %(message)s'


def init_logger() -> logging.Logger:
    """Logger for this mess of an app"""
    if definitions.DEBUG_ENABLED:
        log_levels = ('debug', 'info', 'error')
    else:
        log_levels = ('info', 'error')
    _logger = logging.getLogger()
    if _logger.handlers:
        return _logger
    if not os.path.isdir(definitions.LOG_DIR):
        os.makedirs(definitions.LOG_DIR, exist_ok=True)
    for log_level in log_levels:
        log_file = f'{definitions.LOG_DIR}/{log_level}.log'
        file_handler = handlers.RotatingFileHandler(log_file,
                                                    maxBytes=5 * 1024 * 1024,
                                                    backupCount=10)
        file_handler.setLevel(logging_levels.get(log_level))
        file_handler.setFormatter(Formatter(LOG_FORMAT))
        _logger.addHandler(file_handler)
    return _logger


logger = init_logger()


def asserted(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except exceptions.CufflinksException as exc:
            message = f'[{exc.__class__.__name__} in {func.__module__}] {exc.__doc__}: {exc}'
            logger.fatal(message)
            print(message)
            sys.exit(exc.exit_code)
        except Exception as exc:
            message = f'[{exc.__class__.__name__} in {func.__module__}] {exc.__doc__}: {exc}'
            logger.fatal(message)
            print(message)
            raise
    return wrapper
