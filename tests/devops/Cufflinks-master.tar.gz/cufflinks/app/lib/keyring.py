import json

from app import definitions
from app.lib import exceptions


class Auth:
    def __init__(self, **auth):
        try:
            self._username = auth['username']
            self._password = auth['password']
        except KeyError as exc:
            raise exceptions.AuthorizationError(f'Failed to fetch {exc} from auth, '
                                                f'check formatting of your auth file')

    @property
    def username(self):
        return self._username

    @property
    def password(self):
        return self._password


class Keyring:
    def __init__(self, path=None):
        self._auth_file_path = path if path else definitions.AUTH_FILE_PATH
        self._auth = self._get_auth()

    def _get_auth(self) -> dict:
        try:
            with open(self._auth_file_path) as f:
                contents = json.load(f)
        except FileNotFoundError:
            raise exceptions.AuthorizationError(f'Auth file not found at {self._auth_file_path}, '
                                                f'did you forget to provide credentials?')
        return contents

    def get_auth(self, service: str) -> Auth:
        try:
            return Auth(**self._auth[service])
        except KeyError as exc:
            raise exceptions.AuthorizationError(exc)

    @property
    def jenkins(self):
        return self.get_auth('JENKINS')
