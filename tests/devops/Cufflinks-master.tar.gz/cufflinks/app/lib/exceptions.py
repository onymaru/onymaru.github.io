class CufflinksException(Exception):
    """Base Cuffilnks exception"""
    exit_code = 10


class AuthorizationError(CufflinksException):
    """Failed to access to authorization credentials"""
    exit_code = 11


class JenkinsResponseError(CufflinksException):
    """Unexpected response from Jenkins"""
    exit_code = 12
