import os

JENKINS_URL = os.environ.get('JENKINS_URL', 'http://jenkins.office.stacksoft.ru/')
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
AUTH_FILE_PATH = os.path.join(ROOT_DIR, 'auth/auth.json')
LOG_DIR = os.path.join(ROOT_DIR, 'logs')
DEBUG_ENABLED = True
