#!/usr/bin/env python3

from flask import Flask, render_template, Markup

from app import definitions
from app.lib.logger import logger, asserted
from app.lib import jenkins_api

app = Flask(__name__)
app.logger = logger


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/active_jobs")
def active_jobs():
    link_template = '<a href="{url}">{name}</a>'
    jobs = jenkins_api.get_active_jobs()
    if jobs:
        job_text = '<br>'.join([link_template.format(url=x.url, name=x.name) for x in jobs])
    else:
        job_text = 'Нет активных джобов'
    return render_template("job_list.html", job_list=Markup(job_text))


@app.route("/servers")
def servers():
    server_list = jenkins_api.get_servers()
    line_template = '<li><a href="{url}">{name}</a> - {status}</li>'
    if server_list:
        server_lines = [line_template.format(url=x.url, name=x.name, status=x.status) for x in server_list]
        server_text = '<ul>' + ''.join(server_lines) + '</ul>'
    else:
        server_text = 'Нет серверных джобов'
    return render_template("server_list.html", server_list=Markup(server_text))


@asserted
def main():
    app.run(host='0.0.0.0', port='5000', debug=definitions.DEBUG_ENABLED)
