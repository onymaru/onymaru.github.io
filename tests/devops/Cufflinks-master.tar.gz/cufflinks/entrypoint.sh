#!/bin/sh
echo "Starting application server"
python3 -m gunicorn --workers 3 --bind 0.0.0.0:5000 -m 007 app.app:app